#include <iostream>
#include <iomanip>
#include "lexanalyzer.h"
#include <iomanip>
#include "constvalues.h"
#include "reader.h"

using namespace std;

int main(int argc,char *argv[])
{

    //get the string from the commandline and pass to run
    string str = argv[1];
    run(str);

}
